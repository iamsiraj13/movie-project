export const BASE_URL = "http://192.168.50.245:80/mv";
