// export const BASE_URL = "http://192.168.50.246";
// export const BASE_URL = "https://dummyjson.com";
export const BASE_URL = "http://192.168.50.245:81/mv";
